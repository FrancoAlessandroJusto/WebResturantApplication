from fastapi import APIRouter, HTTPException
from typing import List
from models import MenuItem, Ingrediente

router = APIRouter(prefix="/menu", tags=["menu"])

@router.get("", response_model=List[dict])
def list_menu_items():
    """
    Restituisce tutti gli articoli del menù attivi con ingredienti
    """
    try:
        items = MenuItem.get_all()
        return [item.to_dict() for item in items]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il caricamento: {str(e)}")

@router.get("/{item_id}", response_model=dict)
def get_menu_item(item_id: int):
    """
    Restituisce un singolo articolo del menù
    """
    try:
        items = MenuItem.get_all()
        item = next((item for item in items if item.id == item_id), None)
        
        if not item:
            raise HTTPException(status_code=404, detail="Articolo non trovato")
            
        return item.to_dict()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante il caricamento: {str(e)}")

@router.post("", response_model=dict)
def create_menu_item(item_data: dict):
    """
    Crea un nuovo articolo nel menù con ingredienti
    """
    required_fields = ['nome', 'prezzo', 'categoria']
    for field in required_fields:
        if field not in item_data:
            raise HTTPException(status_code=400, detail=f"Campo '{field}' obbligatorio")
    
    categorie_valide = ['Antipasti', 'Pizza', 'Bevande', 'Dolci', 'Varie']
    if item_data['categoria'] not in categorie_valide:
        raise HTTPException(status_code=400, detail="Categoria non valida")
    
    try:
        nome = item_data['nome'].strip()
        prezzo = float(item_data['prezzo'])
        categoria = item_data['categoria']
        ingredienti_selezionati = item_data.get('ingredienti', [])
        
        # Controlla se il nome esiste già (case insensitive)
        import sqlite3
        from db import get_conn
        conn = get_conn()
        
        existing = conn.execute(
            "SELECT id FROM menu_items WHERE LOWER(nome) = LOWER(?) AND attiva = 1", 
            (nome,)
        ).fetchone()
        
        if existing:
            conn.close()
            raise HTTPException(status_code=409, detail=f"Articolo '{nome}' già esistente nel menù")
        
        conn.close()
        
        # Crea nuovo menu item
        nuovo_item = MenuItem.create(nome, prezzo, categoria, ingredienti_selezionati)
        
        return {
            "id": nuovo_item.id,
            "nome": nuovo_item.nome,
            "prezzo": nuovo_item.prezzo,
            "categoria": nuovo_item.categoria,
            "ingredienti": [ing.to_dict() for ing in nuovo_item.ingredienti],
            "message": "Articolo creato con successo"
        }
        
    except HTTPException:
        raise
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed: menu_items.nome" in str(e):
            raise HTTPException(status_code=409, detail=f"Articolo '{nome}' già esistente nel menù")
        else:
            raise HTTPException(status_code=500, detail=f"Errore database: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante la creazione: {str(e)}")

@router.put("/{item_id}", response_model=dict)
def update_menu_item(item_id: int, item_data: dict):
    """
    Aggiorna un articolo esistente nel menù
    """
    try:
        import sqlite3
        from db import get_conn
        
        conn = get_conn()
        
        # Verifica se l'item esiste
        item = conn.execute(
            "SELECT id FROM menu_items WHERE id = ? AND attiva = 1", 
            (item_id,)
        ).fetchone()
        
        if not item:
            conn.close()
            raise HTTPException(status_code=404, detail="Articolo non trovato")
        
        # Aggiorna i dati base
        conn.execute(
            "UPDATE menu_items SET nome = ?, prezzo = ?, categoria = ? WHERE id = ?",
            (item_data.get('nome', ''), item_data.get('prezzo', 0), item_data.get('categoria', ''), item_id)
        )
        
        # Gestione ingredienti (se presenti)
        if 'ingredienti' in item_data:
            # Rimuovi ingredienti esistenti
            conn.execute("DELETE FROM menu_item_ingredienti WHERE menu_item_id = ?", (item_id,))
            
            # Aggiungi nuovi ingredienti
            for ing in item_data['ingredienti']:
                conn.execute(
                    "INSERT INTO menu_item_ingredienti (menu_item_id, ingrediente_id, quantita) VALUES (?, ?, ?)",
                    (item_id, ing.get('ingrediente_id', 0), ing.get('quantita', 0))
                )
        
        conn.commit()
        conn.close()
        
        return {"message": "Articolo aggiornato con successo"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante l'aggiornamento: {str(e)}")

@router.delete("/{item_id}")
def delete_menu_item(item_id: int):
    """
    Disattiva un menu item (soft delete)
    """
    try:
        import sqlite3
        from db import get_conn
        
        conn = get_conn()
        
        # Controlla se l'item esiste
        item = conn.execute(
            "SELECT nome FROM menu_items WHERE id = ?", (item_id,)
        ).fetchone()
        
        if not item:
            conn.close()
            raise HTTPException(status_code=404, detail="Articolo non trovato")
        
        # Disattiva l'item
        conn.execute(
            "UPDATE menu_items SET attiva = 0 WHERE id = ?",
            (item_id,)
        )
        conn.commit()
        conn.close()
        
        return {"message": f"Articolo '{item['nome']}' eliminato con successo"}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Errore durante l'eliminazione: {str(e)}")
